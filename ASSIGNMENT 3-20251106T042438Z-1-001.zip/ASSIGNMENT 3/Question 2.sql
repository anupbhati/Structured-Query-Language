create database students ;
use students;
create table students (
student_id int primary key auto_increment ,
name_ varchar (50) ,
course varchar (30),
marks int ,
attendance int ,
grade char (1));

INSERT INTO students (name_, course, marks, attendance, grade)
VALUES ('Aarav', 'Maths', 85, 90, 'A'),
	   ('Riya', 'Science', 72, 88, 'B'),
       ('Kabir', 'English', 60, 70, 'C'), 
       ('Neha', 'Maths', 95, 92, 'A'), 
       ('Rahul', 'science', 50 ,65, 'D');
       
select*from students ;       
select *from students where  marks>=85 ;
select* from students where course = 'science';
set sql_safe_updates=0;
update students set marks =marks*1.20 
where marks > 70;

select * from students where marks between 70 and 89 ;

select course , avg (marks) as avg_marks from students group by course;
select*from students  
order by course asc;

select course , count(*) as student_count from students group by course  having count(*)>1;	

   